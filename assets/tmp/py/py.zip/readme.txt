运行环境 Python3

1. 首先安装依赖
pip install pandas requests openpyxl 

2. 运行python脚本
python app.py

原始文件下载： http://www.wingodata.cn/#/dash/public-paper 【公司竞争战略指标_2001_2019】